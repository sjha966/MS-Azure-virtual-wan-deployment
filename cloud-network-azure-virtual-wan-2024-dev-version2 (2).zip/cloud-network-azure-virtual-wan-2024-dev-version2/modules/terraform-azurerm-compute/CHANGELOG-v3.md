# 3.14.0 (May 25, 2021)

ENHANCEMENTS:

* Add variable `delete_data_disks_on_termination`. [#170](https://github.com/Azure/terraform-azurerm-compute/pull/170)

BUG FIXES:
